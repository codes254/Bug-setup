global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['62']
global.gambar = ""